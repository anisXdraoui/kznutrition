const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Créer le dossier uploads s'il n'existe pas
if (!fs.existsSync('./uploads')) {
  fs.mkdirSync('./uploads');
}

// Configuration multer pour l'upload d'images
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// Initialiser la base de données SQLite
const db = new sqlite3.Database('./kznutrition.db', (err) => {
  if (err) {
    console.error('Erreur de connexion à la base de données:', err);
  } else {
    console.log('Connecté à la base de données SQLite');
    initDatabase();
  }
});

// Initialiser les tables
function initDatabase() {
  db.run(`CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    brand TEXT NOT NULL,
    category TEXT NOT NULL,
    price REAL NOT NULL,
    oldPrice REAL,
    description TEXT,
    image TEXT,
    rating REAL DEFAULT 0,
    reviewCount INTEGER DEFAULT 0,
    stock INTEGER DEFAULT 0,
    flavor TEXT,
    size TEXT,
    isNew BOOLEAN DEFAULT 0,
    isBestSeller BOOLEAN DEFAULT 0,
    hasDiscount BOOLEAN DEFAULT 0,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    customerName TEXT,
    phone TEXT NOT NULL,
    wilaya TEXT NOT NULL,
    commune TEXT,
    postalCode TEXT,
    address TEXT NOT NULL,
    paymentMethod TEXT NOT NULL,
    items TEXT NOT NULL,
    subtotal REAL NOT NULL,
    shipping REAL NOT NULL,
    total REAL NOT NULL,
    status TEXT DEFAULT 'En traitement',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    revenue REAL DEFAULT 0,
    orders INTEGER DEFAULT 0
  )`);

  // Ajouter des produits de démonstration
  addSampleProducts();
}

// Ajouter des produits de démonstration
function addSampleProducts() {
  db.get('SELECT COUNT(*) as count FROM products', (err, row) => {
    if (row.count === 0) {
      const sampleProducts = [
        {
          id: uuidv4(),
          name: 'Iso-Gold Whey Protein',
          brand: 'KZ Gold',
          category: 'Prise de masse',
          price: 12500,
          description: '24g de protéines par portion pour aider à construire et maintenir les muscles',
          image: 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?w=500',
          rating: 4.8,
          reviewCount: 2100,
          stock: 50,
          flavor: 'Double Chocolat Riche',
          size: '2kg (4.4lbs)',
          isBestSeller: true
        },
        {
          id: uuidv4(),
          name: 'Rage Pre-Workout',
          brand: 'KZ Performance',
          category: 'Pre-Workout',
          price: 7500,
          oldPrice: 8500,
          description: 'Formule explosive pour une énergie maximale',
          image: 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=500',
          rating: 4.6,
          reviewCount: 1500,
          stock: 30,
          flavor: 'Fruit Punch',
          size: '300g',
          hasDiscount: true
        },
        {
          id: uuidv4(),
          name: 'Pure Creatine 5000',
          brand: 'KZ Pure',
          category: 'Créatine',
          price: 5800,
          description: '5g de créatine monohydrate micronisée premium par portion',
          image: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?w=500',
          rating: 4.9,
          reviewCount: 950,
          stock: 45,
          flavor: 'Nature',
          size: '500g',
          isBestSeller: true
        },
        {
          id: uuidv4(),
          name: 'Multi-V Pack',
          brand: 'KZ Essentials',
          category: 'Vitamines',
          price: 6800,
          description: 'Complexe multivitaminé complet pour soutenir la performance',
          image: 'https://images.unsplash.com/photo-1550572017-4251e6274560?w=500',
          rating: 4.7,
          reviewCount: 800,
          stock: 60,
          size: '60 capsules'
        },
        {
          id: uuidv4(),
          name: 'Original BCAA Poudre',
          brand: 'Xtend',
          category: 'Récupération',
          price: 6500,
          description: '7g de BCAAs, récupération musculaire + électrolytes',
          image: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?w=500',
          rating: 4.5,
          reviewCount: 320,
          stock: 25,
          flavor: 'Fruit Punch',
          size: '400g'
        },
        {
          id: uuidv4(),
          name: 'Super Mass Gainer',
          brand: 'Dymatize',
          category: 'Prise de masse',
          price: 9800,
          description: 'Gainer de masse hypercalorique en poudre',
          image: 'https://images.unsplash.com/photo-1556909172-54557c7e4fb7?w=500',
          rating: 4.7,
          reviewCount: 940,
          stock: 15,
          flavor: 'Chocolat',
          size: '2.7kg'
        },
        {
          id: uuidv4(),
          name: 'Animal Pak Multivitamine',
          brand: 'Animal',
          category: 'Vitamines',
          price: 7200,
          description: "Le pack d'entraînement tout-en-un complet",
          image: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=500',
          rating: 4.9,
          reviewCount: 980,
          stock: 8,
          size: '44 packs',
          isNew: true
        },
        {
          id: uuidv4(),
          name: 'Gold Standard 100% Whey',
          brand: 'Optimum Nutrition',
          category: 'Prise de masse',
          price: 12500,
          description: '24g de protéines par portion',
          image: 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=500',
          rating: 4.8,
          reviewCount: 2100,
          stock: 120,
          flavor: 'Double Chocolat',
          size: '2kg',
          isBestSeller: true
        },
        {
          id: uuidv4(),
          name: 'C4 Original Pre-Workout',
          brand: 'Cellucor',
          category: 'Pre-Workout',
          price: 5800,
          description: 'Énergie explosive, concentration accrue et une envie irrésistible de soulever',
          image: 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?w=500',
          rating: 4.6,
          reviewCount: 850,
          stock: 40,
          flavor: 'Fruit Punch',
          size: '390g'
        },
        {
          id: uuidv4(),
          name: 'Platinum 100% Créatine',
          brand: 'MuscleTech',
          category: 'Créatine',
          price: 3900,
          oldPrice: 4600,
          description: '5g de créatine monohydrate micronisée premium',
          image: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?w=500',
          rating: 4.9,
          reviewCount: 1200,
          stock: 5,
          size: '400g',
          hasDiscount: true
        }
      ];

      const stmt = db.prepare(`INSERT INTO products VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
      sampleProducts.forEach(product => {
        stmt.run(
          product.id,
          product.name,
          product.brand,
          product.category,
          product.price,
          product.oldPrice || null,
          product.description,
          product.image,
          product.rating,
          product.reviewCount,
          product.stock,
          product.flavor || null,
          product.size,
          product.isNew ? 1 : 0,
          product.isBestSeller ? 1 : 0,
          product.hasDiscount ? 1 : 0,
          new Date().toISOString()
        );
      });
      stmt.finalize();
      console.log('Produits de démonstration ajoutés');
    }
  });
}

// ==================== ROUTES PRODUITS ====================

// Obtenir tous les produits avec filtres
app.get('/api/products', (req, res) => {
  const { category, brand, minPrice, maxPrice, search, sortBy } = req.query;
  
  let query = 'SELECT * FROM products WHERE 1=1';
  const params = [];

  if (category && category !== 'all') {
    query += ' AND category = ?';
    params.push(category);
  }

  if (brand) {
    query += ' AND brand = ?';
    params.push(brand);
  }

  if (minPrice) {
    query += ' AND price >= ?';
    params.push(parseFloat(minPrice));
  }

  if (maxPrice) {
    query += ' AND price <= ?';
    params.push(parseFloat(maxPrice));
  }

  if (search) {
    query += ' AND (name LIKE ? OR description LIKE ? OR brand LIKE ?)';
    const searchPattern = `%${search}%`;
    params.push(searchPattern, searchPattern, searchPattern);
  }

  // Tri
  if (sortBy === 'price-asc') {
    query += ' ORDER BY price ASC';
  } else if (sortBy === 'price-desc') {
    query += ' ORDER BY price DESC';
  } else if (sortBy === 'name') {
    query += ' ORDER BY name ASC';
  } else if (sortBy === 'rating') {
    query += ' ORDER BY rating DESC';
  } else {
    query += ' ORDER BY createdAt DESC';
  }

  db.all(query, params, (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows);
  });
});

// Obtenir un produit par ID
app.get('/api/products/:id', (req, res) => {
  db.get('SELECT * FROM products WHERE id = ?', [req.params.id], (err, row) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    if (!row) {
      res.status(404).json({ error: 'Produit non trouvé' });
      return;
    }
    res.json(row);
  });
});

// Ajouter un nouveau produit
app.post('/api/products', upload.single('image'), (req, res) => {
  const {
    name, brand, category, price, oldPrice, description,
    rating, reviewCount, stock, flavor, size, isNew, isBestSeller, hasDiscount
  } = req.body;

  const id = uuidv4();
  const image = req.file ? `/uploads/${req.file.filename}` : null;

  db.run(
    `INSERT INTO products VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      id, name, brand, category, parseFloat(price), oldPrice ? parseFloat(oldPrice) : null,
      description, image, parseFloat(rating) || 0, parseInt(reviewCount) || 0,
      parseInt(stock), flavor, size, isNew === 'true' ? 1 : 0,
      isBestSeller === 'true' ? 1 : 0, hasDiscount === 'true' ? 1 : 0,
      new Date().toISOString()
    ],
    function(err) {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }
      res.json({ id, message: 'Produit ajouté avec succès' });
    }
  );
});

// Mettre à jour un produit
app.put('/api/products/:id', upload.single('image'), (req, res) => {
  const {
    name, brand, category, price, oldPrice, description,
    rating, reviewCount, stock, flavor, size, isNew, isBestSeller, hasDiscount
  } = req.body;

  let query = `UPDATE products SET 
    name = ?, brand = ?, category = ?, price = ?, oldPrice = ?,
    description = ?, rating = ?, reviewCount = ?, stock = ?,
    flavor = ?, size = ?, isNew = ?, isBestSeller = ?, hasDiscount = ?`;
  
  const params = [
    name, brand, category, parseFloat(price), oldPrice ? parseFloat(oldPrice) : null,
    description, parseFloat(rating) || 0, parseInt(reviewCount) || 0,
    parseInt(stock), flavor, size, isNew === 'true' ? 1 : 0,
    isBestSeller === 'true' ? 1 : 0, hasDiscount === 'true' ? 1 : 0
  ];

  if (req.file) {
    query += ', image = ?';
    params.push(`/uploads/${req.file.filename}`);
  }

  query += ' WHERE id = ?';
  params.push(req.params.id);

  db.run(query, params, function(err) {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    if (this.changes === 0) {
      res.status(404).json({ error: 'Produit non trouvé' });
      return;
    }
    res.json({ message: 'Produit mis à jour avec succès' });
  });
});

// Supprimer un produit
app.delete('/api/products/:id', (req, res) => {
  db.run('DELETE FROM products WHERE id = ?', [req.params.id], function(err) {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    if (this.changes === 0) {
      res.status(404).json({ error: 'Produit non trouvé' });
      return;
    }
    res.json({ message: 'Produit supprimé avec succès' });
  });
});

// Obtenir les catégories disponibles
app.get('/api/categories', (req, res) => {
  db.all('SELECT DISTINCT category FROM products', (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows.map(row => row.category));
  });
});

// Obtenir les marques disponibles
app.get('/api/brands', (req, res) => {
  db.all('SELECT DISTINCT brand FROM products', (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows.map(row => row.brand));
  });
});

// ==================== ROUTES COMMANDES ====================

// Créer une nouvelle commande
app.post('/api/orders', (req, res) => {
  const {
    customerName, phone, wilaya, commune, postalCode, address,
    paymentMethod, items, subtotal, shipping, total
  } = req.body;

  const id = uuidv4();

  // Vérifier et mettre à jour le stock
  const itemsArray = JSON.parse(items);
  let stockError = false;

  itemsArray.forEach(item => {
    db.get('SELECT stock FROM products WHERE id = ?', [item.id], (err, row) => {
      if (err || !row || row.stock < item.quantity) {
        stockError = true;
      } else {
        db.run('UPDATE products SET stock = stock - ? WHERE id = ?', [item.quantity, item.id]);
      }
    });
  });

  if (stockError) {
    res.status(400).json({ error: 'Stock insuffisant pour certains produits' });
    return;
  }

  db.run(
    `INSERT INTO orders VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      id, customerName, phone, wilaya, commune, postalCode, address,
      paymentMethod, items, parseFloat(subtotal), parseFloat(shipping),
      parseFloat(total), 'En traitement', new Date().toISOString()
    ],
    function(err) {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }

      // Mettre à jour les statistiques
      const today = new Date().toISOString().split('T')[0];
      db.run(
        `INSERT INTO stats (date, revenue, orders) VALUES (?, ?, 1)
         ON CONFLICT(date) DO UPDATE SET revenue = revenue + ?, orders = orders + 1`,
        [today, parseFloat(total), parseFloat(total)]
      );

      res.json({ id, message: 'Commande créée avec succès' });
    }
  );
});

// Obtenir toutes les commandes
app.get('/api/orders', (req, res) => {
  const { status, limit } = req.query;
  
  let query = 'SELECT * FROM orders';
  const params = [];

  if (status && status !== 'all') {
    query += ' WHERE status = ?';
    params.push(status);
  }

  query += ' ORDER BY createdAt DESC';

  if (limit) {
    query += ' LIMIT ?';
    params.push(parseInt(limit));
  }

  db.all(query, params, (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows);
  });
});

// Obtenir une commande par ID
app.get('/api/orders/:id', (req, res) => {
  db.get('SELECT * FROM orders WHERE id = ?', [req.params.id], (err, row) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    if (!row) {
      res.status(404).json({ error: 'Commande non trouvée' });
      return;
    }
    res.json(row);
  });
});

// Mettre à jour le statut d'une commande
app.patch('/api/orders/:id/status', (req, res) => {
  const { status } = req.body;

  db.run(
    'UPDATE orders SET status = ? WHERE id = ?',
    [status, req.params.id],
    function(err) {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }
      if (this.changes === 0) {
        res.status(404).json({ error: 'Commande non trouvée' });
        return;
      }
      res.json({ message: 'Statut mis à jour avec succès' });
    }
  );
});

// ==================== ROUTES STATISTIQUES ====================

// Obtenir les statistiques du dashboard
app.get('/api/stats/dashboard', (req, res) => {
  const stats = {};

  // Chiffre d'affaires total
  db.get('SELECT SUM(total) as revenue FROM orders', (err, row) => {
    stats.totalRevenue = row.revenue || 0;

    // Nombre de commandes actives
    db.get('SELECT COUNT(*) as count FROM orders WHERE status IN (?, ?)', 
      ['En traitement', 'Expédition'], (err, row) => {
      stats.activeOrders = row.count || 0;

      // Produits en stock faible
      db.get('SELECT COUNT(*) as count FROM products WHERE stock <= 10', (err, row) => {
        stats.lowStock = row.count || 0;

        // Chiffre d'affaires du mois dernier
        const lastMonth = new Date();
        lastMonth.setMonth(lastMonth.getMonth() - 1);
        const lastMonthStr = lastMonth.toISOString().split('T')[0].substring(0, 7);

        db.get(
          `SELECT SUM(total) as revenue FROM orders WHERE strftime('%Y-%m', createdAt) = ?`,
          [lastMonthStr],
          (err, row) => {
            const lastMonthRevenue = row.revenue || 0;
            stats.percentageChange = stats.totalRevenue > 0 
              ? ((stats.totalRevenue - lastMonthRevenue) / lastMonthRevenue * 100).toFixed(2)
              : 0;

            // Ventes des 30 derniers jours
            db.all(
              `SELECT date(createdAt) as date, SUM(total) as revenue 
               FROM orders 
               WHERE createdAt >= date('now', '-30 days')
               GROUP BY date(createdAt)
               ORDER BY date(createdAt)`,
              (err, rows) => {
                stats.salesData = rows || [];

                // Meilleurs ventes
                db.all(
                  `SELECT p.*, SUM(json_extract(value, '$.quantity')) as unitsSold
                   FROM products p, orders o, json_each(o.items)
                   WHERE p.id = json_extract(value, '$.id')
                   GROUP BY p.id
                   ORDER BY unitsSold DESC
                   LIMIT 5`,
                  (err, rows) => {
                    stats.topProducts = rows || [];
                    res.json(stats);
                  }
                );
              }
            );
          }
        );
      });
    });
  });
});

// ==================== DÉMARRAGE DU SERVEUR ====================

app.listen(PORT, () => {
  console.log(`Serveur démarré sur le port ${PORT}`);
  console.log(`API disponible sur http://localhost:${PORT}/api`);
});

// Gestion de la fermeture propre
process.on('SIGINT', () => {
  db.close((err) => {
    if (err) {
      console.error(err.message);
    }
    console.log('Base de données fermée');
    process.exit(0);
  });
});
