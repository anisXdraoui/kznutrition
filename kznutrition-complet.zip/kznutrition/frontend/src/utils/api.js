import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';
const API_ENDPOINT = `${API_ENDPOINT}/api`;

// ==================== PRODUITS ====================

export const getProducts = async (filters = {}) => {
  try {
    const params = new URLSearchParams();
    Object.keys(filters).forEach(key => {
      if (filters[key]) params.append(key, filters[key]);
    });
    
    const response = await axios.get(`${API_ENDPOINT}/products?${params}`);
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la récupération des produits:', error);
    throw error;
  }
};

export const getProduct = async (id) => {
  try {
    const response = await axios.get(`${API_ENDPOINT}/products/${id}`);
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la récupération du produit:', error);
    throw error;
  }
};

export const createProduct = async (productData) => {
  try {
    const formData = new FormData();
    Object.keys(productData).forEach(key => {
      formData.append(key, productData[key]);
    });
    
    const response = await axios.post(`${API_ENDPOINT}/products`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la création du produit:', error);
    throw error;
  }
};

export const updateProduct = async (id, productData) => {
  try {
    const formData = new FormData();
    Object.keys(productData).forEach(key => {
      formData.append(key, productData[key]);
    });
    
    const response = await axios.put(`${API_ENDPOINT}/products/${id}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la mise à jour du produit:', error);
    throw error;
  }
};

export const deleteProduct = async (id) => {
  try {
    const response = await axios.delete(`${API_ENDPOINT}/products/${id}`);
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la suppression du produit:', error);
    throw error;
  }
};

export const getCategories = async () => {
  try {
    const response = await axios.get(`${API_ENDPOINT}/categories`);
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la récupération des catégories:', error);
    throw error;
  }
};

export const getBrands = async () => {
  try {
    const response = await axios.get(`${API_ENDPOINT}/brands`);
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la récupération des marques:', error);
    throw error;
  }
};

// ==================== COMMANDES ====================

export const createOrder = async (orderData) => {
  try {
    const response = await axios.post(`${API_ENDPOINT}/orders`, orderData);
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la création de la commande:', error);
    throw error;
  }
};

export const getOrders = async (filters = {}) => {
  try {
    const params = new URLSearchParams();
    Object.keys(filters).forEach(key => {
      if (filters[key]) params.append(key, filters[key]);
    });
    
    const response = await axios.get(`${API_ENDPOINT}/orders?${params}`);
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la récupération des commandes:', error);
    throw error;
  }
};

export const getOrder = async (id) => {
  try {
    const response = await axios.get(`${API_ENDPOINT}/orders/${id}`);
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la récupération de la commande:', error);
    throw error;
  }
};

export const updateOrderStatus = async (id, status) => {
  try {
    const response = await axios.patch(`${API_ENDPOINT}/orders/${id}/status`, { status });
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la mise à jour du statut:', error);
    throw error;
  }
};

// ==================== STATISTIQUES ====================

export const getDashboardStats = async () => {
  try {
    const response = await axios.get(`${API_ENDPOINT}/stats/dashboard`);
    return response.data;
  } catch (error) {
    console.error('Erreur lors de la récupération des statistiques:', error);
    throw error;
  }
};
