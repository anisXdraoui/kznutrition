import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, X } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { getProducts, getCategories, getBrands } from '../utils/api';

const Shop = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  const [filters, setFilters] = useState({
    category: searchParams.get('category') || '',
    brand: searchParams.get('brand') || '',
    minPrice: searchParams.get('minPrice') || '',
    maxPrice: searchParams.get('maxPrice') || '',
    search: searchParams.get('search') || '',
    sortBy: searchParams.get('sortBy') || 'newest'
  });

  useEffect(() => {
    fetchCategories();
    fetchBrands();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [filters]);

  const fetchCategories = async () => {
    try {
      const data = await getCategories();
      setCategories(data);
    } catch (error) {
      console.error('Erreur:', error);
    }
  };

  const fetchBrands = async () => {
    try {
      const data = await getBrands();
      setBrands(data);
    } catch (error) {
      console.error('Erreur:', error);
    }
  };

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const data = await getProducts(filters);
      setProducts(data);
    } catch (error) {
      console.error('Erreur:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (key, value) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    
    // Mettre à jour l'URL
    const params = new URLSearchParams();
    Object.keys(newFilters).forEach(k => {
      if (newFilters[k]) params.set(k, newFilters[k]);
    });
    setSearchParams(params);
  };

  const clearFilters = () => {
    const newFilters = {
      category: '',
      brand: '',
      minPrice: '',
      maxPrice: '',
      search: '',
      sortBy: 'newest'
    };
    setFilters(newFilters);
    setSearchParams({});
  };

  const activeFiltersCount = Object.values(filters).filter(v => v && v !== 'newest').length;

  return (
    <div className="min-h-screen bg-gray-900 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-3xl md:text-4xl font-bold text-white">
              Suppléments <span className="text-yellow-500">Performance</span>
            </h1>
            
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="lg:hidden bg-gray-800 text-white px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <Filter className="w-5 h-5" />
              Filtres {activeFiltersCount > 0 && `(${activeFiltersCount})`}
            </button>
          </div>

          <p className="text-gray-400">
            {products.length} produit{products.length > 1 ? 's' : ''} trouvé{products.length > 1 ? 's' : ''}
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filtres */}
          <aside className={`lg:w-64 ${showFilters ? 'block' : 'hidden lg:block'}`}>
            <div className="bg-gray-800 rounded-lg p-6 sticky top-20">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-white font-bold text-lg">Filtres</h2>
                {activeFiltersCount > 0 && (
                  <button
                    onClick={clearFilters}
                    className="text-yellow-500 text-sm hover:text-yellow-400"
                  >
                    Réinitialiser
                  </button>
                )}
              </div>

              {/* Objectif */}
              <div className="mb-6">
                <h3 className="text-white font-semibold mb-3">Objectif</h3>
                <select
                  value={filters.category}
                  onChange={(e) => handleFilterChange('category', e.target.value)}
                  className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                >
                  <option value="">Toutes les catégories</option>
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              {/* Fourchette de prix */}
              <div className="mb-6">
                <h3 className="text-white font-semibold mb-3">Fourchette de prix</h3>
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Min"
                    value={filters.minPrice}
                    onChange={(e) => handleFilterChange('minPrice', e.target.value)}
                    className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                  />
                  <input
                    type="number"
                    placeholder="Max"
                    value={filters.maxPrice}
                    onChange={(e) => handleFilterChange('maxPrice', e.target.value)}
                    className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                  />
                </div>
                <div className="flex justify-between text-gray-400 text-xs mt-2">
                  <span>0 DA</span>
                  <span>15000 DA</span>
                </div>
              </div>

              {/* Marques */}
              <div className="mb-6">
                <h3 className="text-white font-semibold mb-3">Marques</h3>
                <select
                  value={filters.brand}
                  onChange={(e) => handleFilterChange('brand', e.target.value)}
                  className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                >
                  <option value="">Toutes les marques</option>
                  {brands.map((brand) => (
                    <option key={brand} value={brand}>{brand}</option>
                  ))}
                </select>
              </div>
            </div>
          </aside>

          {/* Produits */}
          <div className="flex-1">
            {/* Tri */}
            <div className="flex justify-between items-center mb-6">
              <div className="text-gray-400 text-sm">
                Trier par:
              </div>
              <select
                value={filters.sortBy}
                onChange={(e) => handleFilterChange('sortBy', e.target.value)}
                className="bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
              >
                <option value="newest">Plus récent</option>
                <option value="price-asc">Prix: croissant</option>
                <option value="price-desc">Prix: décroissant</option>
                <option value="name">Nom</option>
                <option value="rating">Meilleure note</option>
              </select>
            </div>

            {/* Filtres actifs */}
            {activeFiltersCount > 0 && (
              <div className="flex flex-wrap gap-2 mb-6">
                {filters.category && (
                  <span className="bg-yellow-500 text-black px-3 py-1 rounded-full text-sm font-medium flex items-center gap-2">
                    {filters.category}
                    <button onClick={() => handleFilterChange('category', '')}>
                      <X className="w-4 h-4" />
                    </button>
                  </span>
                )}
                {filters.brand && (
                  <span className="bg-yellow-500 text-black px-3 py-1 rounded-full text-sm font-medium flex items-center gap-2">
                    {filters.brand}
                    <button onClick={() => handleFilterChange('brand', '')}>
                      <X className="w-4 h-4" />
                    </button>
                  </span>
                )}
                {(filters.minPrice || filters.maxPrice) && (
                  <span className="bg-yellow-500 text-black px-3 py-1 rounded-full text-sm font-medium flex items-center gap-2">
                    {filters.minPrice || '0'} - {filters.maxPrice || '∞'} DA
                    <button onClick={() => {
                      handleFilterChange('minPrice', '');
                      handleFilterChange('maxPrice', '');
                    }}>
                      <X className="w-4 h-4" />
                    </button>
                  </span>
                )}
              </div>
            )}

            {/* Grille de produits */}
            {loading ? (
              <div className="text-center text-white py-20">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-yellow-500 mx-auto"></div>
                <p className="mt-4">Chargement...</p>
              </div>
            ) : products.length === 0 ? (
              <div className="text-center text-white py-20">
                <p className="text-xl mb-4">Aucun produit trouvé</p>
                <button
                  onClick={clearFilters}
                  className="text-yellow-500 hover:text-yellow-400"
                >
                  Réinitialiser les filtres
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Shop;
