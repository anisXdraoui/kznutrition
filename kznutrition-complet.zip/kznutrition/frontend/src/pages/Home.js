import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, Truck, Award, Zap, Headphones } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { getProducts } from '../utils/api';

const Home = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const data = await getProducts({ limit: 4 });
        setProducts(data);
      } catch (error) {
        console.error('Erreur:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const categories = [
    {
      name: 'Prise de masse',
      image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=500',
      link: '/boutique?category=Prise de masse'
    },
    {
      name: 'Vitamines',
      image: 'https://images.unsplash.com/photo-1550572017-4251e6274560?w=500',
      link: '/boutique?category=Vitamines'
    },
    {
      name: 'Créatine',
      image: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?w=500',
      link: '/boutique?category=Créatine'
    }
  ];

  const features = [
    {
      icon: <Truck className="w-8 h-8" />,
      title: 'Livraison à Wilaya',
      description: 'Livraison rapide dans toute l\'Algérie'
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: 'Certifié Halal',
      description: 'Tous nos produits sont certifiés'
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Résultats Rapides',
      description: 'Performance optimale garantie'
    },
    {
      icon: <Headphones className="w-8 h-8" />,
      title: 'Support 24/7',
      description: 'Assistance disponible à tout moment'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Hero Section */}
      <section className="relative h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
        <div className="absolute inset-0 opacity-20">
          <img
            src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1600"
            alt="Background"
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="relative container mx-auto px-4 h-full flex items-center">
          <div className="max-w-3xl">
            <div className="inline-block bg-yellow-500 text-black text-sm font-bold px-4 py-2 rounded-full mb-6">
              🔥 TENDANCE ACTUELLE
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              BÂTISSEZ
              <br />
              <span className="text-yellow-500">VOTRE</span>
              <br />
              HÉRITAGE
            </h1>
            
            <p className="text-gray-300 text-lg mb-8 max-w-xl">
              Suppléments premium conçus pour une performance d'élite. 
              Plante nettée en laboratoire pour les athlètes qui exigent le meilleur.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <Link
                to="/boutique"
                className="bg-yellow-500 text-black px-8 py-4 rounded-lg font-bold hover:bg-yellow-400 transition-all inline-flex items-center gap-2"
              >
                VOIR LES NOUVEAUTÉS
                <ChevronDown className="w-5 h-5 rotate-[-90deg]" />
              </Link>
              
              <Link
                to="/boutique?category=Prise de masse"
                className="border-2 border-white text-white px-8 py-4 rounded-lg font-bold hover:bg-white hover:text-black transition-all"
              >
                MEILLEURES VENTES
              </Link>
            </div>
          </div>
        </div>

        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-gray-400 animate-bounce">
          <div className="flex flex-col items-center">
            <span className="text-sm mb-2">DÉFILER</span>
            <ChevronDown className="w-6 h-6" />
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-black border-y border-yellow-500/20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="flex flex-col items-center text-center p-6 rounded-lg hover:bg-gray-800/50 transition-all"
              >
                <div className="text-yellow-500 mb-4">{feature.icon}</div>
                <h3 className="text-white font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Acheter par objectif */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              ACHETER PAR <span className="text-yellow-500">OBJECTIF</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Trouvez les suppléments parfaits pour votre parcours
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {categories.map((category, index) => (
              <Link
                key={index}
                to={category.link}
                className="relative h-80 rounded-lg overflow-hidden group"
              >
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent flex items-end">
                  <h3 className="text-white text-2xl font-bold p-6 uppercase">
                    {category.name}
                  </h3>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-8">
            <Link
              to="/boutique"
              className="text-yellow-500 hover:text-yellow-400 font-semibold inline-flex items-center gap-2"
            >
              VOIR TOUTES LES CATÉGORIES
              <ChevronDown className="w-5 h-5 rotate-[-90deg]" />
            </Link>
          </div>
        </div>
      </section>

      {/* Produits populaires */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">
                PRODUITS <span className="text-yellow-500">TENDANCES</span>
              </h2>
              <p className="text-gray-400">Nos suppléments les plus populaires</p>
            </div>
            <Link
              to="/boutique"
              className="hidden md:block bg-yellow-500 text-black px-6 py-3 rounded-lg font-bold hover:bg-yellow-400 transition-all"
            >
              VOIR TOUS LES PRODUITS
            </Link>
          </div>

          {loading ? (
            <div className="text-center text-white py-20">
              <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-yellow-500 mx-auto"></div>
              <p className="mt-4">Chargement...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}

          <div className="text-center mt-8 md:hidden">
            <Link
              to="/boutique"
              className="bg-yellow-500 text-black px-6 py-3 rounded-lg font-bold hover:bg-yellow-400 transition-all inline-block"
            >
              VOIR TOUS LES PRODUITS
            </Link>
          </div>
        </div>
      </section>

      {/* Offre promotionnelle */}
      <section className="py-20 bg-gradient-to-br from-yellow-500 to-yellow-600">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <div className="inline-block bg-black text-yellow-500 text-sm font-bold px-4 py-2 rounded-full mb-6">
              OFFRE LIMITÉE
            </div>
            
            <h2 className="text-4xl md:text-6xl font-bold text-black mb-6">
              ACHETEZ-EN 1
              <br />
              OBTENEZ LE 2ÈME
              <br />
              À -50%
            </h2>
            
            <p className="text-black text-lg mb-8 max-w-xl">
              Faites le plein de vos suppléments préférés cette semaine seulement! 
              *Mélangez les saveurs.
            </p>
            
            <Link
              to="/boutique"
              className="bg-black text-yellow-500 px-8 py-4 rounded-lg font-bold hover:bg-gray-900 transition-all inline-block"
            >
              PROFITER DE L'OFFRE
            </Link>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-20 bg-gray-900 border-t border-yellow-500/20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            REJOIGNEZ LA <span className="text-yellow-500">TEAM</span>
          </h2>
          <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
            Obtenez des offres exclusives, des conseils d'entraînement et un accès anticipé aux nouveautés.
          </p>
          
          <form className="max-w-md mx-auto flex gap-4">
            <input
              type="email"
              placeholder="Entrez votre email"
              className="flex-1 bg-gray-800 text-white rounded-lg px-6 py-4 focus:outline-none focus:ring-2 focus:ring-yellow-500"
            />
            <button
              type="submit"
              className="bg-yellow-500 text-black px-8 py-4 rounded-lg font-bold hover:bg-yellow-400 transition-all"
            >
              S'ABONNER
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};

export default Home;
