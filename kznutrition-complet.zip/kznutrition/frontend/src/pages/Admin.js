import React, { useEffect, useState } from 'react';
import { 
  Package, ShoppingCart, AlertTriangle, TrendingUp, 
  Plus, Edit2, Trash2, X, Search
} from 'lucide-react';
import { 
  getDashboardStats, getProducts, getOrders, 
  createProduct, updateProduct, deleteProduct, updateOrderStatus 
} from '../utils/api';

const Admin = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [stats, setStats] = useState(null);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const [productForm, setProductForm] = useState({
    name: '',
    brand: '',
    category: '',
    price: '',
    oldPrice: '',
    description: '',
    image: null,
    rating: '0',
    reviewCount: '0',
    stock: '',
    flavor: '',
    size: '',
    isNew: false,
    isBestSeller: false,
    hasDiscount: false
  });

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      if (activeTab === 'dashboard') {
        const data = await getDashboardStats();
        setStats(data);
      } else if (activeTab === 'products') {
        const data = await getProducts();
        setProducts(data);
      } else if (activeTab === 'orders') {
        const data = await getOrders();
        setOrders(data);
      }
    } catch (error) {
      console.error('Erreur:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleProductFormChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    setProductForm({
      ...productForm,
      [name]: type === 'checkbox' ? checked : type === 'file' ? files[0] : value
    });
  };

  const handleProductSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (editingProduct) {
        await updateProduct(editingProduct.id, productForm);
      } else {
        await createProduct(productForm);
      }
      
      setShowProductModal(false);
      setEditingProduct(null);
      setProductForm({
        name: '',
        brand: '',
        category: '',
        price: '',
        oldPrice: '',
        description: '',
        image: null,
        rating: '0',
        reviewCount: '0',
        stock: '',
        flavor: '',
        size: '',
        isNew: false,
        isBestSeller: false,
        hasDiscount: false
      });
      fetchData();
    } catch (error) {
      console.error('Erreur:', error);
      alert('Erreur lors de la sauvegarde du produit');
    } finally {
      setLoading(false);
    }
  };

  const handleEditProduct = (product) => {
    setEditingProduct(product);
    setProductForm({
      name: product.name,
      brand: product.brand,
      category: product.category,
      price: product.price.toString(),
      oldPrice: product.oldPrice?.toString() || '',
      description: product.description,
      image: null,
      rating: product.rating.toString(),
      reviewCount: product.reviewCount.toString(),
      stock: product.stock.toString(),
      flavor: product.flavor || '',
      size: product.size || '',
      isNew: product.isNew === 1,
      isBestSeller: product.isBestSeller === 1,
      hasDiscount: product.hasDiscount === 1
    });
    setShowProductModal(true);
  };

  const handleDeleteProduct = async (id) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer ce produit?')) {
      try {
        await deleteProduct(id);
        fetchData();
      } catch (error) {
        console.error('Erreur:', error);
        alert('Erreur lors de la suppression du produit');
      }
    }
  };

  const handleOrderStatusChange = async (orderId, newStatus) => {
    try {
      await updateOrderStatus(orderId, newStatus);
      fetchData();
    } catch (error) {
      console.error('Erreur:', error);
      alert('Erreur lors de la mise à jour du statut');
    }
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.brand.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 border-b border-yellow-500/20">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-white">
              Aperçu du <span className="text-yellow-500">Tableau de Bord</span>
            </h1>
            <div className="text-gray-400 text-sm">
              24 Oct 2023 - Aujourd'hui
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="flex gap-6">
          {/* Sidebar */}
          <aside className="w-64">
            <nav className="bg-gray-800 rounded-lg p-4 space-y-2">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'dashboard'
                    ? 'bg-yellow-500 text-black font-semibold'
                    : 'text-gray-300 hover:bg-gray-700'
                }`}
              >
                📊 Tableau de Bord
              </button>
              <button
                onClick={() => setActiveTab('products')}
                className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'products'
                    ? 'bg-yellow-500 text-black font-semibold'
                    : 'text-gray-300 hover:bg-gray-700'
                }`}
              >
                📦 Produits
              </button>
              <button
                onClick={() => setActiveTab('orders')}
                className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                  activeTab === 'orders'
                    ? 'bg-yellow-500 text-black font-semibold'
                    : 'text-gray-300 hover:bg-gray-700'
                }`}
              >
                🛍️ Commandes
              </button>
            </nav>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {loading && activeTab === 'dashboard' ? (
              <div className="text-center text-white py-20">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-yellow-500 mx-auto"></div>
              </div>
            ) : activeTab === 'dashboard' && stats ? (
              <div className="space-y-6">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-gray-800 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-gray-400 text-sm">Chiffre d'Affaires</h3>
                      <div className="bg-green-500/20 p-2 rounded">
                        <Package className="w-6 h-6 text-green-500" />
                      </div>
                    </div>
                    <p className="text-white text-3xl font-bold">
                      {stats.totalRevenue?.toLocaleString()} DZD
                    </p>
                    <p className="text-green-500 text-sm mt-2 flex items-center gap-1">
                      <TrendingUp className="w-4 h-4" />
                      {stats.percentageChange}% vs mois dernier
                    </p>
                  </div>

                  <div className="bg-gray-800 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-gray-400 text-sm">Commandes Actives</h3>
                      <div className="bg-blue-500/20 p-2 rounded">
                        <ShoppingCart className="w-6 h-6 text-blue-500" />
                      </div>
                    </div>
                    <p className="text-white text-3xl font-bold">{stats.activeOrders}</p>
                    <p className="text-gray-400 text-sm mt-2">
                      12 Traitement • 33 Expédition
                    </p>
                  </div>

                  <div className="bg-gray-800 rounded-lg p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-gray-400 text-sm">Stock Faible</h3>
                      <div className="bg-orange-500/20 p-2 rounded">
                        <AlertTriangle className="w-6 h-6 text-orange-500" />
                      </div>
                    </div>
                    <p className="text-white text-3xl font-bold">{stats.lowStock}</p>
                    <button className="text-yellow-500 text-sm mt-2 hover:text-yellow-400">
                      Besoin Réappro →
                    </button>
                  </div>
                </div>

                {/* Sales Chart */}
                <div className="bg-gray-800 rounded-lg p-6">
                  <h3 className="text-white font-bold text-xl mb-4">
                    Vélocité des Ventes
                  </h3>
                  <div className="text-gray-400 text-sm mb-4">30 Derniers Jours</div>
                  
                  <div className="h-64 flex items-end gap-2">
                    {stats.salesData?.map((day, index) => {
                      const maxRevenue = Math.max(...stats.salesData.map(d => d.revenue));
                      const height = (day.revenue / maxRevenue) * 100;
                      const isToday = index === stats.salesData.length - 1;
                      
                      return (
                        <div key={index} className="flex-1 flex flex-col items-center">
                          <div
                            className={`w-full rounded-t ${isToday ? 'bg-yellow-500' : 'bg-gray-600'}`}
                            style={{ height: `${height}%` }}
                          />
                          <div className="text-xs text-gray-400 mt-2">
                            {new Date(day.date).toLocaleDateString('fr-FR', { weekday: 'short' })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  
                  <div className="text-yellow-500 text-sm mt-4">
                    {stats.salesData?.[stats.salesData.length - 1]?.revenue.toLocaleString()} DA vendredi
                  </div>
                </div>

                {/* Top Products */}
                <div className="bg-gray-800 rounded-lg p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-white font-bold text-xl">Meilleures Ventes</h3>
                    <button className="text-yellow-500 text-sm hover:text-yellow-400">
                      Voir Tous les Produits
                    </button>
                  </div>

                  <div className="space-y-3">
                    {stats.topProducts?.map((product) => (
                      <div key={product.id} className="flex items-center gap-4 p-3 bg-gray-700 rounded-lg">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-16 h-16 object-cover rounded"
                        />
                        <div className="flex-1">
                          <h4 className="text-white font-semibold">{product.name}</h4>
                          <p className="text-gray-400 text-sm">{product.unitsSold} unités vendues</p>
                        </div>
                        <div className="text-yellow-500 font-bold">
                          {(product.price * product.unitsSold).toLocaleString()} DA
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : activeTab === 'products' ? (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Rechercher un produit..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-gray-800 text-white rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    />
                  </div>
                  <button
                    onClick={() => {
                      setEditingProduct(null);
                      setShowProductModal(true);
                    }}
                    className="bg-yellow-500 text-black px-6 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-all flex items-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    Nouveau Produit
                  </button>
                </div>

                <div className="bg-gray-800 rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-700">
                      <tr>
                        <th className="text-left p-4 text-gray-300 font-semibold">Produit</th>
                        <th className="text-left p-4 text-gray-300 font-semibold">Catégorie</th>
                        <th className="text-left p-4 text-gray-300 font-semibold">Prix</th>
                        <th className="text-left p-4 text-gray-300 font-semibold">Stock</th>
                        <th className="text-left p-4 text-gray-300 font-semibold">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredProducts.map((product) => (
                        <tr key={product.id} className="border-t border-gray-700 hover:bg-gray-700/50">
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <img
                                src={product.image}
                                alt={product.name}
                                className="w-12 h-12 object-cover rounded"
                              />
                              <div>
                                <div className="text-white font-semibold">{product.name}</div>
                                <div className="text-gray-400 text-sm">{product.brand}</div>
                              </div>
                            </div>
                          </td>
                          <td className="p-4 text-gray-300">{product.category}</td>
                          <td className="p-4 text-yellow-500 font-semibold">
                            {product.price.toLocaleString()} DA
                          </td>
                          <td className="p-4">
                            <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                              product.stock === 0 ? 'bg-red-500/20 text-red-500' :
                              product.stock <= 10 ? 'bg-orange-500/20 text-orange-500' :
                              'bg-green-500/20 text-green-500'
                            }`}>
                              {product.stock}
                            </span>
                          </td>
                          <td className="p-4">
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleEditProduct(product)}
                                className="p-2 bg-blue-500/20 text-blue-500 rounded hover:bg-blue-500/30 transition-colors"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteProduct(product.id)}
                                className="p-2 bg-red-500/20 text-red-500 rounded hover:bg-red-500/30 transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : activeTab === 'orders' ? (
              <div>
                <h2 className="text-white font-bold text-2xl mb-6">Commandes Récentes</h2>
                
                <div className="bg-gray-800 rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-700">
                      <tr>
                        <th className="text-left p-4 text-gray-300 font-semibold">ID Commande</th>
                        <th className="text-left p-4 text-gray-300 font-semibold">Client</th>
                        <th className="text-left p-4 text-gray-300 font-semibold">Produits</th>
                        <th className="text-left p-4 text-gray-300 font-semibold">Date</th>
                        <th className="text-left p-4 text-gray-300 font-semibold">Montant</th>
                        <th className="text-left p-4 text-gray-300 font-semibold">Statut</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.map((order) => {
                        const items = JSON.parse(order.items);
                        return (
                          <tr key={order.id} className="border-t border-gray-700 hover:bg-gray-700/50">
                            <td className="p-4 text-yellow-500 font-mono text-sm">
                              #{order.id.substring(0, 8)}
                            </td>
                            <td className="p-4">
                              <div className="text-white">{order.customerName || 'Client'}</div>
                              <div className="text-gray-400 text-sm">{order.phone}</div>
                            </td>
                            <td className="p-4 text-gray-300">
                              {items.map(item => item.name).join(', ').substring(0, 30)}...
                            </td>
                            <td className="p-4 text-gray-300 text-sm">
                              {new Date(order.createdAt).toLocaleDateString('fr-FR')}
                            </td>
                            <td className="p-4 text-yellow-500 font-semibold">
                              {order.total.toLocaleString()} DA
                            </td>
                            <td className="p-4">
                              <select
                                value={order.status}
                                onChange={(e) => handleOrderStatusChange(order.id, e.target.value)}
                                className={`px-3 py-1 rounded-full text-sm font-semibold bg-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-yellow-500 ${
                                  order.status === 'Expédié' ? 'text-green-500' :
                                  order.status === 'En traitement' ? 'text-blue-500' :
                                  'text-orange-500'
                                }`}
                              >
                                <option value="En traitement">En traitement</option>
                                <option value="Expédition">Expédition</option>
                                <option value="Expédié">Expédié</option>
                                <option value="Annulé">Annulé</option>
                              </select>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : null}
          </main>
        </div>
      </div>

      {/* Product Modal */}
      {showProductModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-white font-bold text-2xl">
                  {editingProduct ? 'Modifier le Produit' : 'Nouveau Produit'}
                </h2>
                <button
                  onClick={() => setShowProductModal(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={handleProductSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-gray-400 mb-2 text-sm">Nom *</label>
                    <input
                      type="text"
                      name="name"
                      value={productForm.name}
                      onChange={handleProductFormChange}
                      required
                      className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-400 mb-2 text-sm">Marque *</label>
                    <input
                      type="text"
                      name="brand"
                      value={productForm.brand}
                      onChange={handleProductFormChange}
                      required
                      className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-400 mb-2 text-sm">Catégorie *</label>
                    <select
                      name="category"
                      value={productForm.category}
                      onChange={handleProductFormChange}
                      required
                      className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    >
                      <option value="">Sélectionner</option>
                      <option value="Prise de masse">Prise de masse</option>
                      <option value="Pre-Workout">Pre-Workout</option>
                      <option value="Créatine">Créatine</option>
                      <option value="Vitamines">Vitamines</option>
                      <option value="Récupération">Récupération</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-400 mb-2 text-sm">Prix (DA) *</label>
                    <input
                      type="number"
                      name="price"
                      value={productForm.price}
                      onChange={handleProductFormChange}
                      required
                      className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-400 mb-2 text-sm">Ancien Prix (DA)</label>
                    <input
                      type="number"
                      name="oldPrice"
                      value={productForm.oldPrice}
                      onChange={handleProductFormChange}
                      className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-400 mb-2 text-sm">Stock *</label>
                    <input
                      type="number"
                      name="stock"
                      value={productForm.stock}
                      onChange={handleProductFormChange}
                      required
                      className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-400 mb-2 text-sm">Goût</label>
                    <input
                      type="text"
                      name="flavor"
                      value={productForm.flavor}
                      onChange={handleProductFormChange}
                      className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-400 mb-2 text-sm">Taille</label>
                    <input
                      type="text"
                      name="size"
                      value={productForm.size}
                      onChange={handleProductFormChange}
                      className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-gray-400 mb-2 text-sm">Description</label>
                  <textarea
                    name="description"
                    value={productForm.description}
                    onChange={handleProductFormChange}
                    rows="3"
                    className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                  />
                </div>

                <div>
                  <label className="block text-gray-400 mb-2 text-sm">Image</label>
                  <input
                    type="file"
                    name="image"
                    accept="image/*"
                    onChange={handleProductFormChange}
                    className="w-full bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                  />
                </div>

                <div className="flex gap-4">
                  <label className="flex items-center gap-2 text-white cursor-pointer">
                    <input
                      type="checkbox"
                      name="isNew"
                      checked={productForm.isNew}
                      onChange={handleProductFormChange}
                      className="rounded"
                    />
                    Nouveau
                  </label>

                  <label className="flex items-center gap-2 text-white cursor-pointer">
                    <input
                      type="checkbox"
                      name="isBestSeller"
                      checked={productForm.isBestSeller}
                      onChange={handleProductFormChange}
                      className="rounded"
                    />
                    Meilleure vente
                  </label>

                  <label className="flex items-center gap-2 text-white cursor-pointer">
                    <input
                      type="checkbox"
                      name="hasDiscount"
                      checked={productForm.hasDiscount}
                      onChange={handleProductFormChange}
                      className="rounded"
                    />
                    En promotion
                  </label>
                </div>

                <div className="flex gap-4 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowProductModal(false)}
                    className="flex-1 bg-gray-700 text-white py-3 rounded-lg font-semibold hover:bg-gray-600 transition-all"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-yellow-500 text-black py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-all disabled:opacity-50"
                  >
                    {loading ? 'Enregistrement...' : 'Enregistrer'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Admin;
