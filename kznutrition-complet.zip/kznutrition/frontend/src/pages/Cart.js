import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Minus, Plus, X, ShoppingBag, Lock, CreditCard, Truck } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { createOrder } from '../utils/api';

const Cart = () => {
  const { cart, updateQuantity, removeFromCart, getCartTotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);

  const [formData, setFormData] = useState({
    customerName: '',
    phone: '',
    wilaya: '',
    commune: '',
    postalCode: '',
    address: '',
    paymentMethod: 'cash'
  });

  const shippingCost = 500;
  const subtotal = getCartTotal();
  const total = subtotal + shippingCost;

  const wilayas = [
    'Adrar', 'Chlef', 'Laghouat', 'Oum El Bouaghi', 'Batna', 'Béjaïa', 'Biskra', 'Béchar',
    'Blida', 'Bouira', 'Tamanrasset', 'Tébessa', 'Tlemcen', 'Tiaret', 'Tizi Ouzou',
    'Alger', 'Djelfa', 'Jijel', 'Sétif', 'Saïda', 'Skikda', 'Sidi Bel Abbès',
    'Annaba', 'Guelma', 'Constantine', 'Médéa', 'Mostaganem', 'M\'Sila', 'Mascara',
    'Ouargla', 'Oran', 'El Bayadh', 'Illizi', 'Bordj Bou Arreridj', 'Boumerdès',
    'El Tarf', 'Tindouf', 'Tissemsilt', 'El Oued', 'Khenchela', 'Souk Ahras',
    'Tipaza', 'Mila', 'Aïn Defla', 'Naâma', 'Aïn Témouchent', 'Ghardaïa', 'Relizane'
  ];

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const orderData = {
        ...formData,
        items: JSON.stringify(cart),
        subtotal,
        shipping: shippingCost,
        total
      };

      await createOrder(orderData);
      clearCart();
      alert('Commande créée avec succès! Nous vous contacterons bientôt.');
      navigate('/');
    } catch (error) {
      console.error('Erreur:', error);
      alert('Erreur lors de la création de la commande');
    } finally {
      setLoading(false);
    }
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-gray-900 py-16">
        <div className="container mx-auto px-4 text-center">
          <ShoppingBag className="w-24 h-24 text-gray-700 mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-white mb-4">Votre panier est vide</h2>
          <p className="text-gray-400 mb-8">
            Découvrez nos suppléments premium et commencez votre transformation
          </p>
          <Link
            to="/boutique"
            className="bg-yellow-500 text-black px-8 py-3 rounded-lg font-bold hover:bg-yellow-400 transition-all inline-block"
          >
            Continuer vos achats
          </Link>
        </div>
      </div>
    );
  }

  if (showCheckout) {
    return (
      <div className="min-h-screen bg-gray-900 py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <button
              onClick={() => setShowCheckout(false)}
              className="text-yellow-500 mb-6 hover:text-yellow-400 flex items-center gap-2"
            >
              ← Retour au panier
            </button>

            <h1 className="text-3xl font-bold text-white mb-8">
              <Lock className="inline w-8 h-8 mr-2" />
              Paiement Sécurisé
            </h1>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Formulaire */}
              <div className="lg:col-span-2">
                <form onSubmit={handleSubmit} className="bg-gray-800 rounded-lg p-6">
                  <h2 className="text-white font-bold text-xl mb-6">
                    Informations de livraison
                  </h2>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-gray-400 mb-2 text-sm">
                        Nom complet (optionnel)
                      </label>
                      <input
                        type="text"
                        name="customerName"
                        value={formData.customerName}
                        onChange={handleInputChange}
                        className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                      />
                    </div>

                    <div>
                      <label className="block text-gray-400 mb-2 text-sm">
                        Numéro de téléphone *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        placeholder="05 50 00 00 00"
                        value={formData.phone}
                        onChange={handleInputChange}
                        required
                        className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                      />
                    </div>

                    <div>
                      <label className="block text-gray-400 mb-2 text-sm">
                        Adresse de livraison *
                      </label>
                      <select
                        name="wilaya"
                        value={formData.wilaya}
                        onChange={handleInputChange}
                        required
                        className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-yellow-500 mb-3"
                      >
                        <option value="">Sélectionnez votre Wilaya</option>
                        {wilayas.map((wilaya) => (
                          <option key={wilaya} value={wilaya}>{wilaya}</option>
                        ))}
                      </select>

                      <div className="grid grid-cols-2 gap-3 mb-3">
                        <input
                          type="text"
                          name="commune"
                          placeholder="Commune / Ville"
                          value={formData.commune}
                          onChange={handleInputChange}
                          className="bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                        />
                        <input
                          type="text"
                          name="postalCode"
                          placeholder="Code Postal"
                          value={formData.postalCode}
                          onChange={handleInputChange}
                          className="bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                        />
                      </div>

                      <textarea
                        name="address"
                        placeholder="Adresse complète (Rue, Bâtiment...)"
                        value={formData.address}
                        onChange={handleInputChange}
                        required
                        rows="3"
                        className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-yellow-500"
                      />
                    </div>

                    <div>
                      <label className="block text-gray-400 mb-3 text-sm">
                        Moyen de Paiement *
                      </label>
                      
                      <div className="space-y-3">
                        <label className="flex items-center p-4 bg-gray-700 rounded-lg cursor-pointer hover:bg-gray-600 transition-colors">
                          <input
                            type="radio"
                            name="paymentMethod"
                            value="cash"
                            checked={formData.paymentMethod === 'cash'}
                            onChange={handleInputChange}
                            className="mr-3"
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 text-white font-semibold">
                              <Truck className="w-5 h-5 text-yellow-500" />
                              Paiement à la livraison
                            </div>
                            <p className="text-gray-400 text-sm mt-1">
                              Payez en espèces à la réception
                            </p>
                          </div>
                        </label>

                        <label className="flex items-center p-4 bg-gray-700 rounded-lg cursor-pointer hover:bg-gray-600 transition-colors">
                          <input
                            type="radio"
                            name="paymentMethod"
                            value="ccp"
                            checked={formData.paymentMethod === 'ccp'}
                            onChange={handleInputChange}
                            className="mr-3"
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 text-white font-semibold">
                              <CreditCard className="w-5 h-5 text-yellow-500" />
                              CCP / BaridiMob
                            </div>
                            <p className="text-gray-400 text-sm mt-1">
                              Virement postal sécurisé
                            </p>
                          </div>
                        </label>

                        <label className="flex items-center p-4 bg-gray-700 rounded-lg cursor-pointer hover:bg-gray-600 transition-colors">
                          <input
                            type="radio"
                            name="paymentMethod"
                            value="card"
                            checked={formData.paymentMethod === 'card'}
                            onChange={handleInputChange}
                            className="mr-3"
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 text-white font-semibold">
                              <CreditCard className="w-5 h-5 text-yellow-500" />
                              Carte CIB / Edhahabia
                            </div>
                            <p className="text-gray-400 text-sm mt-1">
                              Paiement en ligne
                            </p>
                          </div>
                        </label>
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full mt-6 bg-yellow-500 text-black py-4 rounded-lg font-bold hover:bg-yellow-400 transition-all disabled:opacity-50"
                  >
                    {loading ? 'Traitement...' : 'CONFIRMER LA COMMANDE →'}
                  </button>

                  <p className="text-gray-400 text-xs text-center mt-4">
                    En passant cette commande, vous acceptez nos{' '}
                    <a href="#" className="text-yellow-500">Conditions Générales</a> et notre{' '}
                    <a href="#" className="text-yellow-500">Politique de Confidentialité</a>.
                  </p>
                </form>
              </div>

              {/* Résumé */}
              <div className="lg:col-span-1">
                <div className="bg-gray-800 rounded-lg p-6 sticky top-20">
                  <h3 className="text-white font-bold text-xl mb-4">Résumé</h3>
                  
                  <div className="space-y-3 mb-4">
                    {cart.map((item) => (
                      <div key={item.id} className="flex gap-3 text-sm">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-16 object-cover rounded"
                        />
                        <div className="flex-1">
                          <p className="text-white font-medium line-clamp-2">{item.name}</p>
                          <p className="text-gray-400 text-xs">Qté: {item.quantity}</p>
                        </div>
                        <p className="text-yellow-500 font-bold">
                          {(item.price * item.quantity).toLocaleString()} DA
                        </p>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-gray-700 pt-4 space-y-2">
                    <div className="flex justify-between text-gray-400">
                      <span>Sous-total</span>
                      <span>{subtotal.toLocaleString()} DA</span>
                    </div>
                    <div className="flex justify-between text-gray-400">
                      <span>Livraison (Yalidine)</span>
                      <span>{shippingCost.toLocaleString()} DA</span>
                    </div>
                    <div className="flex justify-between text-gray-400 text-sm">
                      <span>TVA</span>
                      <span>Inclus</span>
                    </div>
                    <div className="border-t border-gray-700 pt-2 flex justify-between text-white font-bold text-xl">
                      <span>Total à payer</span>
                      <span className="text-yellow-500">{total.toLocaleString()} DA</span>
                    </div>
                  </div>

                  <div className="mt-6 flex items-center gap-2 text-gray-400 text-xs">
                    <Lock className="w-4 h-4" />
                    <span>Paiement 100% sécurisé</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-white mb-8">Votre Stock</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Liste des produits */}
          <div className="lg:col-span-2">
            <div className="bg-gray-800 rounded-lg p-6">
              <p className="text-gray-400 mb-6">
                Vérifiez vos compléments et préparez-vous à progresser.
              </p>

              <div className="space-y-4">
                {cart.map((item) => (
                  <div
                    key={item.id}
                    className="flex gap-4 p-4 bg-gray-700 rounded-lg"
                  >
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-24 h-24 object-cover rounded"
                    />

                    <div className="flex-1">
                      <h3 className="text-white font-semibold mb-1">{item.name}</h3>
                      <p className="text-gray-400 text-sm mb-2">
                        {item.flavor && `Goût: ${item.flavor}`}
                        {item.size && ` • Taille: ${item.size}`}
                      </p>
                      <p className="text-yellow-500 font-bold text-xl">
                        {item.price.toLocaleString()} DA
                      </p>
                    </div>

                    <div className="flex flex-col items-end justify-between">
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <X className="w-5 h-5" />
                      </button>

                      <div className="flex items-center gap-2 bg-gray-800 rounded-lg">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="px-3 py-2 text-white hover:text-yellow-500"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="text-white font-semibold w-8 text-center">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="px-3 py-2 text-white hover:text-yellow-500"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Résumé */}
          <div className="lg:col-span-1">
            <div className="bg-gray-800 rounded-lg p-6 sticky top-20">
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-gray-400">
                  <span>Sous-total</span>
                  <span>{subtotal.toLocaleString()} DA</span>
                </div>
                <div className="flex justify-between text-gray-400">
                  <span>Livraison (Yalidine)</span>
                  <span>{shippingCost.toLocaleString()} DA</span>
                </div>
                <div className="flex justify-between text-gray-400 text-sm">
                  <span>TVA</span>
                  <span>Inclus</span>
                </div>
                <div className="border-t border-gray-700 pt-3 flex justify-between text-white font-bold text-xl">
                  <span>Total à payer</span>
                  <span className="text-yellow-500">{total.toLocaleString()} DA</span>
                </div>
              </div>

              <button
                onClick={() => setShowCheckout(true)}
                className="w-full bg-yellow-500 text-black py-4 rounded-lg font-bold hover:bg-yellow-400 transition-all"
              >
                CONFIRMER LA COMMANDE →
              </button>

              <div className="mt-6 space-y-2 text-xs text-gray-400">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  <span>Paiement sécurisé</span>
                </div>
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4" />
                  <span>Livraison rapide</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
