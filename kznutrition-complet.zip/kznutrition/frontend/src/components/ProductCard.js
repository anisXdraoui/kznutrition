import React from 'react';
import { Star, ShoppingCart, AlertTriangle } from 'lucide-react';
import { useCart } from '../context/CartContext';

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
  };

  const stockStatus = () => {
    if (product.stock === 0) return { text: 'Rupture de stock', color: 'bg-red-500' };
    if (product.stock <= 10) return { text: 'Stock faible', color: 'bg-orange-500' };
    return { text: 'En stock', color: 'bg-green-500' };
  };

  const status = stockStatus();

  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-yellow-500 transition-all duration-300 group">
      {/* Image */}
      <div className="relative h-64 bg-gray-700 overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
        />
        
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-2">
          {product.isNew && (
            <span className="bg-blue-500 text-white text-xs font-bold px-2 py-1 rounded">
              NOUVEAU
            </span>
          )}
          {product.isBestSeller && (
            <span className="bg-yellow-500 text-black text-xs font-bold px-2 py-1 rounded">
              MEILLEURE VENTE
            </span>
          )}
          {product.hasDiscount && (
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
              -15% OFF
            </span>
          )}
        </div>

        {/* Stock Status */}
        <div className="absolute bottom-2 right-2">
          <span className={`${status.color} text-white text-xs font-bold px-2 py-1 rounded flex items-center gap-1`}>
            {product.stock <= 10 && <AlertTriangle className="w-3 h-3" />}
            {status.text}
          </span>
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <div className="text-xs text-yellow-500 font-semibold mb-1 uppercase">
          {product.brand}
        </div>
        
        <h3 className="text-white font-semibold mb-2 line-clamp-2 h-12">
          {product.name}
        </h3>

        {product.flavor && (
          <p className="text-gray-400 text-xs mb-2">
            Goût: {product.flavor}
          </p>
        )}

        {product.size && (
          <p className="text-gray-400 text-xs mb-2">
            Taille: {product.size}
          </p>
        )}

        {/* Rating */}
        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center">
            <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />
            <span className="text-white text-sm ml-1">{product.rating}</span>
          </div>
          <span className="text-gray-400 text-xs">({product.reviewCount})</span>
        </div>

        {/* Prix */}
        <div className="flex items-baseline gap-2 mb-3">
          <span className="text-yellow-500 font-bold text-2xl">
            {product.price.toLocaleString()} DA
          </span>
          {product.oldPrice && (
            <span className="text-gray-500 line-through text-sm">
              {product.oldPrice.toLocaleString()} DA
            </span>
          )}
        </div>

        {/* Bouton Ajouter au panier */}
        <button
          onClick={handleAddToCart}
          disabled={product.stock === 0}
          className={`w-full py-2 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center gap-2 ${
            product.stock === 0
              ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
              : 'bg-yellow-500 text-black hover:bg-yellow-400 active:scale-95'
          }`}
        >
          <ShoppingCart className="w-5 h-5" />
          {product.stock === 0 ? 'Rupture de stock' : 'Ajouter au panier'}
        </button>

        {product.stock > 0 && product.stock <= 10 && (
          <p className="text-orange-400 text-xs text-center mt-2">
            Plus que {product.stock} en stock!
          </p>
        )}
      </div>
    </div>
  );
};

export default ProductCard;
