/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        yellow: {
          500: '#EAB308',
          400: '#FBBF24',
        },
      },
    },
  },
  plugins: [],
}
